chrome.runtime.onInstalled.addListener(() => {
    console.log("Auto Cookie Rejector installed.");
});
